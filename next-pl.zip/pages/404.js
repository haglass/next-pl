import React from "react";

const PageNotFound = () => {
  return <div>페이지를 찾을수 없습니다.</div>;
};

export default PageNotFound;
